# SIM Recharge Starter

A mobile-first SIM recharge website starter with:
- Airtel, Jio, Vi and BSNL selection
- ₹399 and ₹349 plan cards (displayed as **sample offers** until verified against the operator/provider catalogue)
- Mobile number validation
- WhatsApp share link (requires your WhatsApp number/configuration)
- Checkout/recharge API placeholders
- Honest status states: payment pending, recharge pending, success only after server-side provider confirmation

## Important: what is and is not live

This repository is a **starter project**, not a live recharge service. A static GitHub Pages site cannot securely process payments or perform mobile recharges by itself.

To enable real recharge:
1. Register with a legitimate recharge/B2B aggregator that supports your business and the four operators.
2. Obtain its API documentation and credentials.
3. Implement the provider call in `server/index.js` (never put API secrets in browser JavaScript or GitHub Pages).
4. Connect a payment gateway and verify payment using signed server-side webhooks.
5. Only return `SUCCESS` after the provider confirms the recharge.
6. Replace sample plans with the provider's live plan catalogue and validate operator/circle/eligibility.

Do not ask users to share a promotional link repeatedly as a condition for recharge. Do not display fake reviews or claim a recharge succeeded before confirmation.

## Run locally

Requires Node.js 18+.

```bash
npm install
npm start
```

Open http://localhost:3000

The local server runs in safe preview mode. Checkout returns a clear `NOT_CONFIGURED` response until you integrate a payment gateway and recharge provider.

## Configure your WhatsApp share link

Your supplied WhatsApp Channel URL is already configured in `public/app.js`. The Join / Recharge action opens that channel. The share button opens a prefilled WhatsApp share message. Note: WhatsApp Channels are broadcast-only; a channel link does not let customers privately message the admin. Add a separate WhatsApp chat number/link if you want customers to contact you directly.

## Deploy the frontend to GitHub Pages

GitHub Pages can host the static frontend, but not the Node server:
1. Push this repository to GitHub.
2. In repository Settings → Pages, select Deploy from a branch.
3. Select `main` and `/public` (or use the included GitHub Actions workflow if you move the files to the repository root).
4. For a live business, deploy the `server` folder separately to a Node-compatible host and set `API_BASE` in `public/app.js` to your HTTPS API URL.

For a simple static preview, the included frontend can be opened locally. For a real service, use HTTPS and a proper backend.

## Security checklist

- Keep provider and payment secrets in server environment variables.
- Verify payment gateway signatures on the server.
- Validate mobile number, operator, circle and plan server-side.
- Add rate limiting, logging, fraud checks and privacy/terms pages.
- Do not store full card/UPI credentials.
- Publish your legal business identity, support contact, refund policy and privacy policy.
